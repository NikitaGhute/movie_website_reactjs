
import React, { Component } from 'react';
import axios from 'axios'
import '../../src/App.css'



class SearchMovie extends React.Component {
  state = {
    idValue: '',
    searchResults: [],
  }

  handleInputChange = (event) => {
    const searchValue = event.target.value;
    this.setState({ idValue: searchValue })
    this.fetchMovie(searchValue);
  }

  fetchMovie = (query) => {
    const apiURL =
      `https://api.themoviedb.org/3/search/movie?query=${query}&api_key=cfe422613b250f702980a3bbf9e90716`;
      console.log("line no 19")

    axios.get(apiURL)
      .then(res => {
        this.setState({ searchResults: res.data.results });
        console.log("line no 25", res.data.results)
      })

      .catch(error => {
        console.log("error message", error);
      })

  }

  render() {
    const { idValue, searchResults } = this.state;

    return (
      <>
        <div className="movielist">
          <div>
            <input type="text" placeholder="Search for Movie Title..."
              value={idValue}
              onChange={this.handleInputChange}
            />
            <ul>
              {searchResults.length > 0 &&
                searchResults.map(item => (
                  <li key={item.id}>
                    <div>
                      <figure>
                        <img src={`https://image.tmdb.org/t/p/w500/${item.poster_path}`}
                          alt="movie title" className='search_img'/>
                        <p>{item.title}</p>
                      </figure>
                    </div>
                  </li>
                ))}
            </ul>
          </div>
        </div>
      </>
    )
  }
}

export default SearchMovie;