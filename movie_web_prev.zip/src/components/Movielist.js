
import React, { Component } from 'react';
import axios from 'axios';
import '../../src/App.css'


class Movielist extends Component {
  constructor(props) {
    super(props);
    this.state = {
         movies:[],
         idValue:'',
      hoveredImageId: null,
    searchResults: [],

    };
  }

  handleMouseEnter = (imageId) => {
    this.setState({ hoveredImageId: imageId });
  };

  handleMouseLeave = () => {
    this.setState({ hoveredImageId: null });
  };

  
  componentDidMount(){
    axios.get("https://api.themoviedb.org/3/movie/popular?api_key=cfe422613b250f702980a3bbf9e90716")
      .then(res =>{
          const movies= res.data.results;
          console.log("response here: populer movie",res )
          this.setState({movies});
      })
   }



  render() {

      const {idValue, searchResults}= this.state

    return (
        <>
        <div className="movielist">
           <div className="search_bar">
           <ul>
              {searchResults.length > 0 &&
                searchResults.map(item => (
                  <li key={item.id}>
                    {item.title}
                    <div>
                      <figure style={{float:'left'}}>
                        <img src={`https://image.tmdb.org/t/p/w500/${item.poster_path}`}
                          alt="movie title" />
                        <p>{item.title}</p>
                      </figure>
                    </div>
                  </li>
                ))}
            </ul>
           </div>
        </div>

        {this.state.movies.map((item) => (
            <div className='main_section'>
            <div className="card">
            <div
            key={item.id}
            className="image-item"
            onMouseEnter={() => this.handleMouseEnter(item.id)}
            onMouseLeave={this.handleMouseLeave}
            >
            <img src={`https://image.tmdb.org/t/p/w300_and_h450_bestv2${item.poster_path}`} alt="video image" id="videoImg" />
            {this.state.hoveredImageId === item.id && (
                <div className={`hover_text && hover_eff`}>Movie title:
                {item.title}</div>

                // className={`name ${this.state.isHovered ? 'show' : 'hide'}`}

                )}
                </div>
                </div>
                </div>
                ))
              }
                </>
             
             );
            }
         }
         
        
export default Movielist;
