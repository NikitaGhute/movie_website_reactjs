import {useState, useEffect} from 'react'
import './App.css';
import axios from 'axios';
import Movielist from './components/Movielist';
import SearchMovie from './components/Searchlist';

const API_KEY = 'cfe422613b250f702980a3bbf9e90716'; 

function App() {
  const [query, setQuery] = useState('');
  const [movies, setMovies] = useState([]);

  useEffect(() => {
    if (query) {
      axios
        .get(`https://api.themoviedb.org/3/search/movie?api_key=${API_KEY}&query=${query}`)
        .then((response) => {
          setMovies(response.data.results);
          console.log(response.data.results)
        })
        .catch((error) => {
          console.error('API request error:', error);
        });
    } else {
      setMovies([]); 
    }
  }, [query]);

  return <>
  <div id='wrapper' >
      <SearchMovie onSearch={setQuery} />
    
      <Movielist movies={movies} />
     

    </div>

  </>
    
}


export default App;
